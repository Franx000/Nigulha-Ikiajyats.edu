# Responsive slider timeline with Swiper

A Pen created on CodePen.io. Original URL: [https://codepen.io/marbellairaislc/pen/MWVoXBM](https://codepen.io/marbellairaislc/pen/MWVoXBM).

A responsive slider  timeline made with Swiper lib.